import numpy as np
from scipy import misc
import matplotlib.pyplot as plt

l = misc.lena()

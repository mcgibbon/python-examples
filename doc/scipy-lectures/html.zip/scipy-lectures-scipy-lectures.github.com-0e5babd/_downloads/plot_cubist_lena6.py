import numpy as np
import scipy
import matplotlib.pyplot as plt

l = scipy.misc.lena()

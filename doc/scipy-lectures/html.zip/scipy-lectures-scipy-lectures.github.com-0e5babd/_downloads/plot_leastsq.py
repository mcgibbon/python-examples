"""
Demo scipy.optimize.leastsq
"""

